"""Núcleo determinista. No envía órdenes: solo decide y registra."""
