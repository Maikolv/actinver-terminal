"""Reproducir contexto AMT local: python -m futuros_lab.amt_replay --demo.

CSV: inicio,intervalo,apertura,maximo,minimo,cierre[,disponible_desde].
No inicia Quantower, no se conecta al broker, no envía órdenes.
"""
import argparse
import csv
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from .amt import analizar


def demo():
    filas=[]
    for dia,precio in [(15,6000),(16,6002)]:
        inicio=datetime(2026,10,dia,13,30,tzinfo=UTC)
        for i in range(78):
            filas.append(dict(inicio=(inicio+timedelta(minutes=i*5)).isoformat(),intervalo="5Min",
                              apertura=precio,maximo=precio+.5,minimo=precio-.5,cierre=precio))
    return filas


def main():
    p=argparse.ArgumentParser(description=__doc__)
    origen=p.add_mutually_exclusive_group(required=True)
    origen.add_argument('--csv',type=Path)
    origen.add_argument('--demo',action='store_true')
    p.add_argument('--paso',type=float,default=.25)
    p.add_argument('--hasta',help='Corte ISO 8601 con zona; no incorpora barras ni publicaciones posteriores')
    p.add_argument('--salida',type=Path)
    a=p.parse_args()
    if a.demo:
        barras=demo()
    else:
        with a.csv.open(encoding='utf-8-sig',newline='') as f: barras=list(csv.DictReader(f))
    if len(barras)>100000: p.error('Máximo 100000 barras por ejecución')
    ahora=datetime.fromisoformat(a.hasta.replace('Z','+00:00')) if a.hasta else datetime.now(UTC)
    r=analizar(barras,paso=a.paso,ahora=ahora)
    r.update(modo='CONTEXTO_SIN_ORDENES',datos='SINTÉTICOS' if a.demo else 'CSV del usuario, procedencia no verificada')
    texto=json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False)
    if a.salida: a.salida.write_text(texto,encoding='utf-8')
    print(texto)


if __name__=='__main__': main()
