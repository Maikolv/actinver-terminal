from datetime import UTC, datetime
from futuros_lab.amt import analizar
from futuros_lab.amt_replay import demo


def test_demo_contexto_sin_ordenes():
    r=analizar(demo(),ahora=datetime(2026,10,16,21,tzinfo=UTC))
    assert len(r['sesiones'])==2
    assert r['sesiones'][1]['estado']=='aceptacion_alcista'
    assert r['sesiones'][1]['referencia']['fecha']=='2026-10-15'
    assert r['operable'] is False


def test_replay_no_ve_futuro():
    corte=datetime(2026,10,16,13,40,tzinfo=UTC)
    r=analizar(demo(),ahora=corte)
    assert r['sesiones'][-1]['barras']==2
    assert r['sesiones'][-1]['ib'] is None
