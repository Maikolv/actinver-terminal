using FuturosLab.Nucleo;
using TradingPlatform.BusinessLayer;

namespace FuturosLab.Quantower;

/// <summary>Observador AMT de ticks RECIBIDOS. No cuenta, no órdenes, no historial ficticio.</summary>
public class AmtObservador : Strategy
{
    [InputParameter("Contrato MES/ES/MNQ/NQ",10)] public Symbol Simbolo;
    private readonly object sincronizar = new();
    private PerfilSubasta perfil;
    private DateOnly fecha;
    private string estado="Sin ticks";
    private long ticks;
    private TimeZoneInfo zona;
    public AmtObservador()
    {
        Name="Actinver · AMT observador";
        Description="TPO/VAH/VAL/POC de ticks recibidos RTH NY. Parcial desde arranque; sin órdenes.";
    }
    protected override void OnRun()
    {
        if (Simbolo==null || !new[]{"MES","ES","MNQ","NQ"}.Contains((Simbolo.Root??"").ToUpperInvariant()) || Math.Abs(Simbolo.TickSize-.25)>1e-9)
        { Log("Contrato/tick no válido. Detenido.", StrategyLoggingLevel.Error); Stop(); return; }
        zona=TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        lock(sincronizar) { perfil=new(.25); ticks=0; fecha=default; estado="Esperando ticks RTH (parcial)"; }
        Simbolo.NewLast += Recibir;
    }
    protected override void OnStop() { if (Simbolo!=null) Simbolo.NewLast -= Recibir; }
    private void Recibir(Symbol simbolo, Last last)
    {
        // Time es la hora del proveedor; no se usa el reloj del PC para perfilar un replay.
        var utc=DateTime.SpecifyKind(last.Time,DateTimeKind.Utc);
        var t=TimeZoneInfo.ConvertTimeFromUtc(utc,zona);
        var hora=t.TimeOfDay;
        if(hora<TimeSpan.FromHours(9.5) || hora>=TimeSpan.FromHours(16)) return;
        lock(sincronizar)
        {
            var dia=DateOnly.FromDateTime(t);
            if(dia!=fecha) { perfil=new(.25); fecha=dia; ticks=0; }
            try { perfil.Agregar(last.Price,(int)((hora.TotalMinutes-570)/30)); ticks++; estado="Parcial: ticks desde arranque, no sesión completa"; }
            catch(Exception e) when(e is ArgumentException or OverflowException) { estado="Dato fuera de rango: revisar feed"; }
        }
    }
    [Obsolete("Compatibilidad con métricas del SDK Quantower 1.146.18")]
    protected override List<StrategyMetric> OnGetMetrics()
    {
        lock(sincronizar)
        {
            var a=perfil?.Area();
            return new() {
                new(){Name="Estado",FormattedValue=estado},
                new(){Name="Ticks recibidos",FormattedValue=ticks.ToString()},
                new(){Name="POC TPO observado",FormattedValue=a?.Poc.ToString("F3")??"—"},
                new(){Name="VAL / VAH observado",FormattedValue=a==null?"—":$"{a.Val:F2} / {a.Vah:F2}"},
                new(){Name="Órdenes",FormattedValue="No implementa envío de órdenes"}
            };
        }
    }
}
