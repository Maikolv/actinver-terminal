namespace FuturosLab.Nucleo;

public sealed record AreaSubasta(double Poc, double Val, double Vah, double Fraccion);

/// <summary>Rejilla fija. TPO observado de ticks, una marca por precio/bloque de 30 min.</summary>
public sealed class PerfilSubasta
{
    private readonly double paso;
    private readonly SortedDictionary<int, HashSet<int>> marcas = new();
    public PerfilSubasta(double paso = .25)
    {
        if (!double.IsFinite(paso) || paso <= 0) throw new ArgumentException("Paso inválido");
        this.paso = paso;
    }
    public void Agregar(double precio, int periodo)
    {
        if (!double.IsFinite(precio) || precio <= 0 || periodo < 0) throw new ArgumentException("Tick inválido");
        int k = checked((int)Math.Floor(precio / paso + 1e-9));
        if (marcas.Count > 0 && Math.Max(k, marcas.Keys.Last())-Math.Min(k, marcas.Keys.First()) > 20000)
            throw new ArgumentException("Más de 20000 niveles");
        if (!marcas.TryGetValue(k, out var ps)) marcas[k] = ps = new();
        ps.Add(periodo);
    }
    public AreaSubasta? Area()
    {
        if (marcas.Count == 0) return null;
        int poc = marcas.OrderByDescending(x => x.Value.Count).ThenBy(x => x.Key).First().Key;
        int lo=marcas.Keys.First(), hi=marcas.Keys.Last(), a=poc, b=poc;
        int Peso(int k) => marcas.TryGetValue(k, out var ps) ? ps.Count : 0;
        int total=marcas.Sum(x => x.Value.Count), incluido=Peso(poc);
        while (incluido < .7*total)
        {
            int abajo=a>lo ? Peso(a-1) : -1, arriba=b<hi ? Peso(b+1) : -1;
            if (abajo>=arriba && a>lo) incluido += Peso(--a);
            if (arriba>=abajo && b<hi) incluido += Peso(++b);
        }
        return new((poc+.5)*paso,a*paso,(b+1)*paso,(double)incluido/total);
    }
}
